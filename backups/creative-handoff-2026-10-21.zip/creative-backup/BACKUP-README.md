# Set up creative_luen.dayori 專案備份（2026-10-21，香港）

這是可恢復內容的重建備份，不是所有原檔或完整Chat的無損備份。

## 先看這裡
本次開始檢查時工作區僅有空repo，先前未提交檔已不在。本包依仍可見對話重建四篇最新600字故事，並加入其後新增的第五篇故事及Threads接駁成果、團隊規則、研究來源與限制、歷史審核摘要及總表。詳見docs/recovery-status.md。沒有把缺失原件假稱全部找回。

## 開啟
- CONTENTS-OFFLINE.html：獨立離線閱讀全集，內嵌所有MD與文字；瀏覽器開啟，不需啟動服務或網絡，也不依賴workspace原路徑。
- CONTENTS-OFFLINE.txt：UTF-8單一純文字全集，可直接複製保存。
- content-tracker.xlsx／content-overview.csv：重新產生的五篇總表閱讀版，未接通IG或Google Sheets。
- docs/drafts：五篇最新正文。docs/content-register.md：版本、進度、發布狀態。docs/roles：員工規則。
- RESTORE-PROMPT.txt：開新Chat時貼上並提供本包，協助新AI接手；不保證新Chat自動讀檔或有同樣工具。
- MANIFEST.json：每個封裝內容的路徑、大小與SHA256；雜湊驗證封裝後是否改變，不證明與消失原件一致。

## 保存與恢復
1. 下載ZIP後確認能開啟並解壓；至少打開離線全集和任一故事。若下載仍失敗，本地存在不代表你有備份，不應關閉或刪除現有對話。
2. 將ZIP放在你可控制的裝置，再複製一份至自己的雲端硬碟；本工作區不是持久備份保證。
3. 解壓至新資料夾，開新Chat提供資料夾／檔案及RESTORE-PROMPT內容。先讀缺失說明再工作。
4. 若想保留完整Chat，另使用ChatGPT帳戶可用的匯出資料功能（一般在設定的資料控制，介面依帳戶而異）。本工具無法代替你匯出帳戶對話。保存匯出所得對話作另一份備份。
5. 舊版備份曾存於公開GitHub；本次新ZIP需另行下載保存，不能以舊版代替。

## 更新備份
Python 3執行 `python scripts/build_backup.py`。只封裝明列專案檔，不遞迴收入.git、金鑰、環境檔或自身ZIP。預設輸出至workspace同層；可用 --output-dir 指定你可寫的持久資料夾。Excel匯出需openpyxl，缺少時保留CSV並記錄限制。
每次更新內容後重新打包、下載並核對，舊包保留日期，不覆蓋唯一備份。SHA256清單與ZIP內CRC檢查供驗證。

## 本次完整現況快照
包含現存五篇故事、研究及審稿、團隊MD、Excel／CSV、Threads主機程式與測試、GitHub Actions工作、已批准測試工作檔及發布回執。TEST001已發布並經使用者在手機確認可見，使用者計劃自行刪除，尚未確認完成。長文附文僅離線測試；背景寫稿排程未啟用。
不含密鑰、Render環境變數、GitHub Secrets、.git歷史、舊ZIP與執行快取；早期遺失資料及完整Chat仍未恢復。重建主機時需自行重新設定秘密。
恢復時切勿直接將approved-threads工作檔推送至啟用的發布工作流程，以免觸發歷史工作；先停用工作流程並核對現存發布紀錄，再恢復接駁。

## 2026-10-21更新
- 最新對話／專案標題：Set up creative_luen.dayori（使用者回報）。
- Threads帳戶@luen.dayori，數字ID與原帳戶一致；2026-10-21受認證只讀檢查成功、發布開關啟用，改名後未重新實發。
- 收入兩張AI生成頭像提案及只讀連線檢查回執、工作流程。使用者最終選定的雙人插畫只有對話附件，未取得本地原圖，因此本包僅保存選用決定及圖像描述，不能假稱包含原圖。
- Codex環境先前發布失敗，之後啟動曾失敗，本次重新啟動成功並取回現有檔案；不等同環境已成功Publish。
- 本包是現有專案快照，不是帳戶完整聊天匯出、GitHub完整歷史或Render秘密設定備份。

## 最新交接補充（優先於較早進度描述）
使用者已決定改由可使用 Google Drive 的另一個 Codex 接手。先讀 docs/HANDOFF-2026-10-21.md。本次新增文案 Skill、Google Drive 診斷與支援紀錄、獨立唯讀 OAuth 接駁原型（已暫停，未部署驗證）。原型的 requirements.txt、測試、部署說明一併收錄。Google Cloud API 已啟用不等於本對話已連接 Drive。最終插畫可在目標 Drive 的 Profile Picture 子資料夾實際查找，原圖仍不在本包。
