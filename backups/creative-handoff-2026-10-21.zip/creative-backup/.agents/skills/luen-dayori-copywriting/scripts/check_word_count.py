"""Count story characters using the project's agreed convention, not platform limits."""
import argparse
import json
from pathlib import Path
import unicodedata


def count(text):
    return sum(not c.isspace() and not unicodedata.category(c).startswith('P') for c in text)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('file', type=Path, help='UTF-8 body-only text file')
    parser.add_argument('--target', type=int, default=600)
    args = parser.parse_args()
    if args.target < 0:
        parser.error('target must be nonnegative')
    actual = count(args.file.read_text(encoding='utf-8'))
    print(json.dumps({'file': str(args.file), 'actual': actual, 'target': args.target,
                      'matches': actual == args.target}, ensure_ascii=False))
    return 0 if actual == args.target else 1


if __name__ == '__main__':
    raise SystemExit(main())
