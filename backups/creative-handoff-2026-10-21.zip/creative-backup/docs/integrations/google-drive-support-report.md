# Google Drive工具未載入此Codex對話

受影響對話：Set up creative_luen.dayori（雲端環境設定對話）。

## 問題
Google Drive在帳戶插件設定中已安裝、已連接帳戶、Docs/Drive/Sheets技能均啟用；使用者提供的另一個Chat截圖顯示可對指定資料夾建立、更新及讀回同一Google Doc。但此對話多次@Google Drive後，執行工具清單依然沒有Google工具。

## 重現與已排查
1. 在此對話選取並@Google Drive，傳送已在另一Chat成功讀取的資料夾連結。
2. 工具清單未出現Drive、Docs或Sheets；cloud技能目錄只有兩個環境技能。
3. 已重新整理、重新啟動環境及檢查插件設定。工作區現為running/connected，沒有啟動錯誤。
4. 插件請求google-drive@openai-curated-remote被校驗拒絕：plugin_id must match one of the entries in the <recommended_plugins> list。
5. 環境設定工具不提供app／plugin啟用欄位；未找到可用Sources入口。
6. runtime沒有可用Google outbound identity；保留網絡診斷已過期。

## 請平台核查
- 此種環境設定對話是否支援已安裝Google Drive插件。
- 本對話app選取狀態是否有傳入工具提供層，是否被任務類型或模型限制過濾。
- 插件目錄的識別碼與request_plugin_install允許清單為何不一致。
- 若支援，請恢復此對話Google工具載入，並以只讀資料夾查詢驗證。

未附Token或密鑰。此報告尚未送出；尚未獲平台後台根因或修復確認。
