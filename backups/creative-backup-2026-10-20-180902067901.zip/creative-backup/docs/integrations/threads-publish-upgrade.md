# Threads發布升級準備
- 2026-10-20：使用者詢問帳戶只讀測試成功後下一步。已準備同源網頁、受保護預覽與明確確認發布端點，預設關閉。
- 本地檔：integrations/threads-bridge/server.py、publisher.html、test_server.py、README.md、.gitignore。
- 13項離線測試通過；沒有使用真實帳戶Token，沒有任何真實發布。
- GitHub已更新；Render是否部署新版仍待確認。使用者已同意公開上傳，本輪以單一commit原子更新並逐檔核對；沒有IG、排程、串文或Codex安全工具認證。
- 付費／免費未更改。免費主機的暫存SQLite不能提供跨重啟永久去重，本版只供人工確認單篇測試，非自動定期發布系統。
- 實際發布前需使用者核對指定帳戶、完整文字並明確同意公開發布；不能把同意部署程式當作同意貼文。
- 新增公開設定：THREADS_EXPECTED_USERNAME、PUBLIC_ORIGIN及PUBLISH_ENABLED=false；兩個秘密保留Render，不要求貼進Chat。

- GitHub commit：d63f40b14054a7b723681525ae32f33d8b672db3；https://github.com/theanonymousproduction-ai/creative/commit/d63f40b14054a7b723681525ae32f33d8b672db3。
- 僅上傳server.py、publisher.html、test_server.py、README.md及子目錄.gitignore，未上傳任何Token／服務密鑰或新故事。
- 下一步使用者在Render補設定及手動部署；PUBLISH_ENABLED=false保持關閉。本輪未呼叫/publish、未發帖。
