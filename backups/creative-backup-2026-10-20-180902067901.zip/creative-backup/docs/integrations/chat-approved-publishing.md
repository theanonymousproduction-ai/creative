# 使用者要求的正式流程

2026-10-20使用者澄清：必須在原Chat看到稿，批准指定版本後直接Threads發布，中間不再要求搬文字、開發布頁或第二次確認。Render網頁改為診斷／緊急手動工具，不作日常必要步驟。

## 批准與執行
- Manager先在Chat列帳戶、作品編號與固定版本、主帖和任何附文全文、發布形式（立即／已授權時間）及待批准狀態。600字以主帖+長文附文可保留全文，不得暗中截短或改成另一種形式。
- 使用者在此清楚上下文說Okay／批准／可以出，即授權這個版本；不要求再到Render勾選。一般認可方向、同意設定程式不等於批准任何貼文。
- Manager使用GitHub內容寫入能力提交單一新的批准工作檔，不能改已批准全文；workflow讀私密服務密鑰、自動比對預覽、檢查帳戶及永久嘗試紀錄後呼叫發布；Manager讀結果再更新總表並給實際連結。
- workflow未完成不可說已發帖；結果不明停住核對，不自動重試。功能現在尚待一次性Secrets／主機設定與首次端到端驗證，不能提前稱已自動化。

## 一次性設定與權限
- GitHub Actions repository secret：THREADS_BRIDGE_API_KEY，值由使用者直接填入，等於Render BRIDGE_API_KEY；Threads Token繼續只留Render。
- 現有Codex GitHub連接可讀workflows、可寫repo內容，但讀Actions Secrets與管理設定均403；不能代使用者設定秘密，不要求其貼進Chat。
- GitHub workflow需可執行並授予deployments:write；Render需部署新檔，PUBLISH_ENABLED可在首次實測前一次開啟，之後每篇以批准工作檔授權。
- 存在公開repo中的已批准工作檔會公開內容。若不接受額外GitHub公開副本，先改私人佇列，不擅自將草稿公開。
- 沒有開啟背景自動寫稿或IG；四星期週期的喚起仍未建立，與每次Chat批准後立即發布是兩件事。

## 現狀
- 20項離線測試通過；沒有用真實秘密、沒有建立批准工作檔或發帖。
- 使用者本輪是修正流程，不是批准先前Test或任何故事立即公開。

## GitHub已安裝
- commit：568187dd466e9232d2520a0a4b07b5dda2af8c23。
- .github/workflows/publish-chat-approved.yml已提交main，僅在新增approved-threads/*.json時觸發；本輪未建立該目錄任何工作檔。
- 使用者秘密及Render新版部署待完成，沒有真實端到端發布測試。
