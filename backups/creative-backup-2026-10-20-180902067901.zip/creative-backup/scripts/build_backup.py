"""Build a self-contained, manifest-verified Creative project archive from an explicit allowlist."""
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import argparse,hashlib,html,json,re,zipfile,unicodedata
from export_content_tracker import export
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--output-dir',type=Path,default=ROOT.parent);p.add_argument('--label',default=datetime.now(ZoneInfo('Asia/Hong_Kong')).strftime('%Y-%m-%d'));a=p.parse_args()
if not re.fullmatch(r'[0-9]{4}-[0-9]{2}-[0-9]{2}',a.label): p.error('Label must be YYYY-MM-DD')
output=a.output_dir.resolve();output.mkdir(parents=True,exist_ok=True)
export_result=export()
files=[ROOT/'AGENTS.md',ROOT/'BACKUP-README.md',ROOT/'RESTORE-PROMPT.txt',*sorted((ROOT/'docs').rglob('*.md')),*sorted((ROOT/'scripts').glob('*.py')),ROOT/'content-overview.csv']
files += [*sorted((ROOT/'docs/publications').glob('*.json')), *sorted((ROOT/'.github/workflows').glob('*.yml')), *sorted((ROOT/'approved-threads').glob('*.json'))]
bridge=ROOT/'integrations/threads-bridge'
files += [f for f in sorted(bridge.iterdir()) if f.is_file() and (f.suffix in ('.py','.html','.md') or f.name=='.gitignore')]
if (ROOT/'README.md').exists(): files.append(ROOT/'README.md')
if (ROOT/'content-tracker.xlsx').exists(): files.append(ROOT/'content-tracker.xlsx')
for f in files:
 assert not f.is_symlink() and f.is_file() and f.resolve().is_relative_to(ROOT)
for f in (ROOT/'docs/drafts').glob('*.md'):
 n=sum(not c.isspace() and not unicodedata.category(c).startswith('P') for c in f.read_text())
 assert n==600,(str(f),n)
readable=[f for f in files if f.suffix in ('.md','.txt')]
txt='Creative 專案可恢復內容全集\n標記：對話重建，非完整Chat匯出。完整性見BACKUP-README.md。\n\n'
toc=[];sections=[]
for i,f in enumerate(readable):
 rel=f.relative_to(ROOT).as_posix();body=f.read_text();txt+='\n\n===== '+rel+' =====\n\n'+body
 toc.append(f'<li><a href="#doc{i}">{html.escape(rel)}</a></li>')
 sections.append(f'<section id="doc{i}"><h2>{html.escape(rel)}</h2><pre>{html.escape(body)}</pre><a href="#top">返回目錄</a></section>')
(ROOT/'CONTENTS-OFFLINE.txt').write_text(txt,encoding='utf-8')
page='<!doctype html><html lang="zh-Hant"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Creative 備份全集</title><style>body{max-width:960px;margin:24px auto;padding:0 18px;color:#213547;font:17px/1.8 system-ui,sans-serif;background:#f7f9fc}pre{white-space:pre-wrap;overflow-wrap:anywhere;font:inherit}section{background:white;padding:24px;margin:24px 0;border:1px solid #d7dfeb;border-radius:10px}a{color:#075bb4}h2{overflow-wrap:anywhere}</style><body id="top"><h1>Creative 專案離線備份</h1><p>2026-10-20對話重建；非所有原件或完整Chat。無須網絡，本頁內已嵌入現有文件與五篇正文。</p><nav><ul>'+''.join(toc)+'</ul></nav>'+''.join(sections)+'</body></html>'
(ROOT/'CONTENTS-OFFLINE.html').write_text(page,encoding='utf-8')
files += [ROOT/'CONTENTS-OFFLINE.txt',ROOT/'CONTENTS-OFFLINE.html']
manifest={'created_at_hong_kong':datetime.now(ZoneInfo('Asia/Hong_Kong')).isoformat(),'snapshot_label':a.label,'provenance':'Reconstructed from visible conversation; not full chat export or bit-for-bit recovery','export_result':export_result,'manifest_scope':'All payload files except MANIFEST.json itself; checksum proves archive consistency, not original-file authenticity','files':[]}
for f in files:
 b=f.read_bytes();manifest['files'].append({'path':f.relative_to(ROOT).as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
(ROOT/'MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
archive=output/('creative-backup-'+a.label+'.zip')
if archive.exists():
 archive=output/('creative-backup-'+a.label+'-'+datetime.now(ZoneInfo('Asia/Hong_Kong')).strftime('%H%M%S%f')+'.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for f in [*files,ROOT/'MANIFEST.json']: z.write(f,'creative-backup/'+f.relative_to(ROOT).as_posix())
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 names=z.namelist();assert all(not n.startswith('/') and '..' not in Path(n).parts for n in names)
 for entry in manifest['files']:
  b=z.read('creative-backup/'+entry['path']);assert hashlib.sha256(b).hexdigest()==entry['sha256']
assert not any(n.endswith(('.env','.pem')) or '/.git/' in n for n in names)
sha=hashlib.sha256(archive.read_bytes()).hexdigest()
archive.with_suffix('.zip.sha256').write_text(sha+'  '+archive.name+'\n')
for f in [*files,ROOT/'MANIFEST.json',archive,archive.with_suffix('.zip.sha256')]: f.chmod(0o644)
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'payload_files':len(files),'sha256':sha,'validation':'CRC and all manifest hashes passed; all current stories 600 characters'},ensure_ascii=False))
