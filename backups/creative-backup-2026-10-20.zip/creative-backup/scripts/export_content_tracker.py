"""Rebuild Excel/CSV reading views from the Markdown register; standard library for CSV."""
from pathlib import Path
import csv,re
ROOT=Path(__file__).resolve().parents[1]
def export():
 text=(ROOT/'docs/content-register.md').read_text()
 blocks=re.findall(r'(?m)^\|[^\n]+\n\|[- :|]+\n(?:\|[^\n]+\n)+',text)
 def rows(block):
  lines=block.strip().splitlines()
  return [[re.sub(r'\[([^]]+)\]\([^)]+\)',r'\1',c.strip()) for c in l.strip('|').split('|')] for l in [lines[0],*lines[2:]]]
 tables=[rows(b) for b in blocks]
 assert tables and len(tables[0])==5,'Expected four story entries'
 with (ROOT/'content-overview.csv').open('w',newline='',encoding='utf-8-sig') as f: csv.writer(f).writerows(tables[0])
 try:
  from openpyxl import Workbook,load_workbook
  from openpyxl.styles import Font,PatternFill,Alignment
  from openpyxl.worksheet.table import Table,TableStyleInfo
 except ImportError:
  (ROOT/'content-tracker.xlsx').unlink(missing_ok=True)
  return 'CSV generated; openpyxl unavailable, no Excel generated'
 wb=Workbook();wb.remove(wb.active)
 for i,(name,table) in enumerate(zip(['內容總覽','發布紀錄','更新紀錄'],tables),1):
  ws=wb.create_sheet(name)
  for row in table: ws.append(row)
  ws.freeze_panes='C2';ws.sheet_view.zoomScale=85
  t=Table(displayName='Tracker'+str(i),ref=ws.dimensions)
  t.tableStyleInfo=TableStyleInfo(name='TableStyleMedium2',showRowStripes=True);ws.add_table(t)
  for column in ws.columns: ws.column_dimensions[column[0].column_letter].width=30
  for row in ws:
   for cell in row: cell.alignment=Alignment(wrap_text=True,vertical='top')
  for c in ws[1]: c.fill=PatternFill('solid',fgColor='17365D');c.font=Font(color='FFFFFF',bold=True)
  for n in range(2,ws.max_row+1): ws.row_dimensions[n].height=65
 ws=wb.create_sheet('說明');ws.append(['重建備份','2026-10-20對話重建，非原Excel']);ws.append(['資料來源','docs/content-register.md']);ws.append(['同步','無IG／Google Sheets自動同步，所有發布待確認']);ws.append(['限制','完整性見BACKUP-README.md及docs/recovery-status.md'])
 ws.column_dimensions['A'].width=20;ws.column_dimensions['B'].width=90
 wb.save(ROOT/'content-tracker.xlsx');assert load_workbook(ROOT/'content-tracker.xlsx')['內容總覽'].max_row==5
 return 'CSV and Excel generated'
if __name__=='__main__': print(export())
