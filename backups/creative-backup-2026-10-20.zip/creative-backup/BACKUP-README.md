# Creative 專案備份（2026-10-20，香港）

這是可恢復內容的重建備份，不是所有原檔或完整Chat的無損備份。

## 先看這裡
本次開始檢查時工作區僅有空repo，先前未提交檔已不在。本包依仍可見對話重建四篇最新600字故事、團隊規則、研究來源與限制、歷史審核摘要及總表。詳見docs/recovery-status.md。沒有把缺失原件假稱全部找回。

## 開啟
- CONTENTS-OFFLINE.html：獨立離線閱讀全集，內嵌所有MD與文字；瀏覽器開啟，不需啟動服務或網絡，也不依賴workspace原路徑。
- CONTENTS-OFFLINE.txt：UTF-8單一純文字全集，可直接複製保存。
- content-tracker.xlsx／content-overview.csv：重新產生的四篇總表閱讀版，未接通IG或Google Sheets。
- docs/drafts：四篇最新正文。docs/content-register.md：版本、進度、發布狀態。docs/roles：員工規則。
- RESTORE-PROMPT.txt：開新Chat時貼上並提供本包，協助新AI接手；不保證新Chat自動讀檔或有同樣工具。
- MANIFEST.json：每個封裝內容的路徑、大小與SHA256；雜湊驗證封裝後是否改變，不證明與消失原件一致。

## 保存與恢復
1. 下載ZIP後確認能開啟並解壓；至少打開離線全集和任一故事。若下載仍失敗，本地存在不代表你有備份，不應關閉或刪除現有對話。
2. 將ZIP放在你可控制的裝置，再複製一份至自己的雲端硬碟；本工作區不是持久備份保證。
3. 解壓至新資料夾，開新Chat提供資料夾／檔案及RESTORE-PROMPT內容。先讀缺失說明再工作。
4. 若想保留完整Chat，另使用ChatGPT帳戶可用的匯出資料功能（一般在設定的資料控制，介面依帳戶而異）。本工具無法代替你匯出帳戶對話。保存匯出所得對話作另一份備份。
5. 之後可以把專案提交至GitHub，但本次沒有推送，也沒有聲稱已存雲端。

## 更新備份
Python 3執行 `python scripts/build_backup.py`。只封裝明列專案檔，不遞迴收入.git、金鑰、環境檔或自身ZIP。預設輸出至workspace同層；可用 --output-dir 指定你可寫的持久資料夾。Excel匯出需openpyxl，缺少時保留CSV並記錄限制。
每次更新內容後重新打包、下載並核對，舊包保留日期，不覆蓋唯一備份。SHA256清單與ZIP內CRC檢查供驗證。
