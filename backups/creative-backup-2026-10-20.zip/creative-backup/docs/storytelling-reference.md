# dmnstory 編劇來源（對話重建索引）

歷史對話記載曾取得14篇232張圖片並做辨識及關鍵圖核對；本次無原圖／OCR，未重新讀取。下列僅恢復連結與摘要，不作精確引文或頁碼核對證明。

- S01 https://www.instagram.com/p/DeMt8zTk3sL/ ：寫作前知識、故事形態、製作與交流四項準備。
- S02 https://www.instagram.com/p/Dc3si8iE1hl/ ：生活細節、場景次序、兩難與意象。
- S03 https://www.instagram.com/p/Dbx7ne7k9bk/ ：文風適合讀者與用途；故事收尾不硬加金句。
- S04 https://www.instagram.com/p/DbAt3TdkyFY/ ：人物價值、在乎事項、關係／志業與優缺點。
- S05 https://www.instagram.com/p/Da28n7Rk_0g/ ：對話資訊、目標、策略、回應、精簡與次序。
- S06 https://www.instagram.com/p/Da61DgJE9kZ/ ：類型、任務及行動發展中段。
- S07 https://www.instagram.com/p/DapclW1Adrm/ ：混淆變項、因果與行為需求的創作思考。
- S08 https://www.instagram.com/p/DaDZ0E_k12I/ ：人物獨特生活細節。
- S09 https://www.instagram.com/p/DaAU2AVk7h_/ ：想要、行動、阻礙、結果及比較構思。
- S10 https://www.instagram.com/p/DZ7cm-Ck3zb/ ：欲求資源與決策權。
- S11 https://www.instagram.com/p/DZ3glgQk19d/ ：人物、情節與主旨一致。
- S12 https://www.instagram.com/p/DZsRIJFk5UW/ ：極簡故事的情緒與人物歷程。
- S13 https://www.instagram.com/p/DZpwwXMkyzn/ ：離水之魚與雙向互補。
- S14 https://www.instagram.com/p/DaSvrXBE1UL/ ：必要細節、出現時機與潛台詞。
