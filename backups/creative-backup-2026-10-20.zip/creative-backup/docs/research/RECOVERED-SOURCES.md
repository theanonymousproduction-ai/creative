# 歷史題材來源與限制（恢復摘要，非本輪重新研究）

2026-10-20依可見對話重建。歷史紀錄稱曾實讀，原下載正文、HTTP證據與原研究MD本次均未找回。本次沒有重新取網頁，不可將摘要冒稱本輪實讀。

## 生理性喜歡系列 C002–C004
- PopDaily https://www.popdaily.com.tw/love/1520258 ：通俗媒體用法（想靠近、氣味、接觸及親吻）；非科學來源，不採基因選擇、永久心動等推論。
- vocus／20+ https://vocus.cc/article/6809a0b8fd897800016bf266 ：個人文本用法（非必然一見鍾情、熟悉後仍想握手與擁抱）。經歷未獨立核實，頁面AI created標示歸屬曾未確認；不作科學證據，不改寫私人故事。
- Cleveland Clinic https://health.clevelandclinic.org/love-at-first-sight ：專家科普主要講初見吸引及身體感受，不直接證明長期伴侶或相容。C003曾記重新實讀；C004當輪403未取得。
- Frontiers綜述 https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2016.00687/full ：較早C002研究熱戀注意及動機，群體研究不能診斷個人；自然成癮是作者框架，不當正式診斷。
- 香港PizzaExpress https://www.pizzaexpress.com.hk/takeout ：C002香港微調曾查外賣可行性，不證明香港普遍家聚習慣。
- 共同限制：兩篇中文通俗樣本不是香港共識或民調。沒有完成有系統的Instagram／Threads／論壇原帖與留言研究，也沒有真人訪談。不得把早前讀編劇IG圖當本題社群研究。
- C004嘗試Healthline及大學反覆離合資料未成功，不能稱已完成on-off臨床研究或香港受眾調查。離合背景、原因及選擇為原創虛構。

## C001 麵包店
- https://www.kingarthurbaking.com/recipes/pineapple-buns-bolo-bao-recipe ：特定食譜的裂紋酥皮及架上放涼，不代表全港統一配方。
- https://www.kingarthurbaking.com/blog/2020/07/08/the-best-way-to-store-yeast-bread ：一般酵母麵包包覆保濕與脆皮取捨，不直接證明菠蘿包紙袋保存效果。
- https://www.icho.hk/en/web/icho/representative_list_milk_tea.html ：港式奶茶文化，不證明特定店供糖或營業安排。
- 原稿芝麻成分標示未有根據，修稿已刪；人物、印刷公司及店舖均虛構。
